		<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Lets </b> Link <b>Live</b>
        </div>
        <strong>Copyright &copy; 2016 <a href="#">St34lth Fr34k</a>.</strong> All rights reserved.
      </footer>

   </div>
  </body>
  </html>