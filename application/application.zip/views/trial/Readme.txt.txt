Virtual Classroom API - PHP Sample Libraries
https://www.braincert.com

Discuss it in our forums: https://www.braincert.com/support/discussions/latest
----------------------------------------------------------------------------------------


In html_form.php file, remember to set your API key in the following paramater:

$bc = new Braincert("7UrWbMlO5sAx1fmVlPHK");


- Read API documentation here: https://www.braincert.com/developer/virtualclassroom-api
- Generate API Key: https://www.braincert.com/app/virtualclassroom
- Try hands-on live demo of Virtual Classroom: https://www.braincert.com/try-virtual-classroom